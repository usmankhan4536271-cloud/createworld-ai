# CreateWorld AI — Replit starter

A mobile-first social creator platform starter using Express + Supabase. The UI uses the approved premium black-and-gold direction.

## Run on Replit

1. Create a new **Node.js** Replit project.
2. Upload/extract this project ZIP into the Replit workspace.
3. In the Shell, run `npm install`.
4. Click Run. The app starts on port 3000.

## Connect real accounts and posts

1. Create a project at https://supabase.com.
2. In Supabase, open **Project Settings → API**.
3. Copy the **Project URL** and the **anon/public key**.
4. Open `public/app.js` and replace:
   - `PASTE_YOUR_SUPABASE_PROJECT_URL`
   - `PASTE_YOUR_SUPABASE_ANON_KEY`
5. Open **SQL Editor** in Supabase and run all of `supabase.sql`.
6. Reload the Replit app. Sign-up, login, posting, likes and comments will connect to your database.

## Important security notes

- Use only the Supabase anon/public key in browser code. Never use `service_role` in `app.js`.
- Configure email confirmation and rate limits in Supabase Auth.
- This is an MVP starter, not a production-scale TikTok/Facebook replacement.
- Before public launch, add video transcoding, private/signed media URLs, content reporting, moderation, spam protection, account deletion, privacy policy, terms, backups and monitoring.
- AI generation, DMs, live streaming, ads and creator payouts are UI roadmap items. They need server-side provider integrations and separate security/payment work.
- Do not collect payments until business, tax, refund and payment-provider requirements are reviewed.

## Included

- Responsive dark/gold interface
- Home feed and demo posts
- Supabase email sign-up/login
- Video upload to `videos` storage bucket
- Posts, likes and comments
- Database tables and Row Level Security policies
- Navigation placeholders for Explore, AI Studio, Inbox, Profile and Settings

## Suggested build sequence

1. Connect Supabase and test two accounts.
2. Add profile editing and follow/unfollow.
3. Add real search and Explore ranking.
4. Add secure messaging and notifications.
5. Connect AI generation through a backend (never expose secret API keys in the browser).
6. Add moderation and creator monetization after legal/payment review.
7. Package as an Android app using a trusted wrapper or native app build and complete Play Store testing.
