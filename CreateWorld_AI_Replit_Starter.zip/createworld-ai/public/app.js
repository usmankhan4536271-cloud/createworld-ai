import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

/*
  STEP 1: Create a Supabase project.
  STEP 2: Paste your Project URL and anon/public key below.
  The anon key is designed for browser use. NEVER put a service_role key here.
*/
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (s) => document.querySelector(s);
const content = $("#content");
const feed = $("#feed");
const authDialog = $("#authDialog");
const uploadDialog = $("#uploadDialog");
const noticeDialog = $("#noticeDialog");
let currentUser = null;
let authMode = "login";
let feedMode = "latest";
let demoPosts = [
  {id:"demo1",username:"CreateWorld Team",caption:"Welcome to CreateWorld AI. A new home for ideas, creators and stories. ✨",video_url:"",likes_count:128,comments_count:12,created_at:new Date().toISOString(),demo:true},
  {id:"demo2",username:"Creative Studio",caption:"Your next big idea starts with one small creation. What will you make today?",video_url:"",likes_count:86,comments_count:7,created_at:new Date().toISOString(),demo:true}
];

function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function showNotice(title,text){$("#noticeTitle").textContent=title;$("#noticeText").textContent=text;noticeDialog.showModal()}
$("#noticeOk").addEventListener("click",()=>noticeDialog.close());

function setUser(user){
  currentUser=user;
  $("#authButton").textContent=user ? "Log out" : "Log in";
  $("#topAvatar").textContent=user?.user_metadata?.username?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || "U";
}
async function init(){
  if(supabase){
    const {data:{session}}=await supabase.auth.getSession();
    setUser(session?.user||null);
    supabase.auth.onAuthStateChange((_event,session)=>{setUser(session?.user||null);loadFeed()});
  }else{
    $("#authButton").title="Configure Supabase to enable accounts";
  }
  await loadFeed();
}
function openAuth(mode="login"){
  if(!supabase){showNotice("Connect your database first","Create a free Supabase project, then add your Project URL and anon key in public/app.js. The interface works in preview mode, but real accounts need this connection.");return}
  authMode=mode;
  $("#authTitle").textContent=mode==="login"?"Welcome back":"Create your account";
  $("#authSubmit").textContent=mode==="login"?"Log in":"Create account";
  $("#usernameLabel").classList.toggle("hidden",mode==="login");
  $("#authSwitchText").textContent=mode==="login"?"New here?":"Already have an account?";
  $("#authSwitch").textContent=mode==="login"?"Create account":"Log in";
  authDialog.showModal();
}
$("#authButton").addEventListener("click",async()=>{
  if(currentUser){if(supabase)await supabase.auth.signOut();setUser(null);toast("You have logged out.");}
  else openAuth("login");
});
$("#authSwitch").addEventListener("click",()=>openAuth(authMode==="login"?"signup":"login"));
$("#authForm").addEventListener("submit",async(e)=>{
  e.preventDefault();if(!supabase)return;
  const email=$("#authEmail").value.trim(),password=$("#authPassword").value;
  let result;
  if(authMode==="signup"){
    const username=$("#authUsername").value.trim().replace(/[^a-zA-Z0-9_]/g,"").slice(0,24);
    if(username.length<3){toast("Username must be at least 3 characters.");return}
    result=await supabase.auth.signUp({email,password,options:{data:{username}}});
  }else result=await supabase.auth.signInWithPassword({email,password});
  if(result.error){toast(result.error.message);return}
  if(authMode==="signup"&&!result.data.session){toast("Check your email to confirm your account.");authDialog.close();return}
  setUser(result.data.user);authDialog.close();toast("Welcome to CreateWorld AI!");
});

async function loadFeed(){
  if(!supabase){renderPosts(demoPosts);return}
  const {data,error}=await supabase.from("posts").select("id,user_id,caption,video_url,created_at,profiles(username,avatar_url),likes(count),comments(count)").order("created_at",{ascending:false}).limit(30);
  if(error){console.error(error);renderPosts(demoPosts);return}
  renderPosts(data||[]);
  loadSpotlight();
}
function renderPosts(posts){
  if(!posts.length){feed.innerHTML='<div class="loading-card">No posts yet. Be the first to share a video.</div>';return}
  feed.innerHTML=posts.map(p=>{
    const name=p.profiles?.username||p.username||"Creator";
    const likes=p.likes?.[0]?.count??p.likes_count??0;
    const comments=p.comments?.[0]?.count??p.comments_count??0;
    const media=p.video_url?`<video class="post-video" src="${escapeAttr(p.video_url)}" controls playsinline preload="metadata"></video>`:`<div class="post-video demo-visual" style="display:grid;place-items:center;background:radial-gradient(circle,#59421d,#16130e 65%)"><div style="text-align:center;color:#f0d18b"><div style="font:800 55px Manrope">C▶</div><b>CREATEWORLD AI</b><p style="font-size:10px;letter-spacing:2px">CREATE · SHARE · INSPIRE</p></div></div>`;
    return `<article class="post-card" data-id="${escapeAttr(p.id)}">${media}<div class="post-info"><div class="post-author"><span class="user-dot">${escapeHtml(name[0]?.toUpperCase()||"C")}</span><div><strong>${escapeHtml(name)}</strong><small>${timeAgo(p.created_at)}</small></div></div><p class="post-caption">${escapeHtml(p.caption||"")}</p><div class="post-actions"><button data-action="like" data-id="${escapeAttr(p.id)}">♡ ${likes}</button><button data-action="comment" data-id="${escapeAttr(p.id)}">▢ ${comments}</button><button data-action="share" data-id="${escapeAttr(p.id)}">↗ Share</button></div></div></article>`;
  }).join("");
}
function escapeHtml(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(v=""){return escapeHtml(v)}
function timeAgo(date){const mins=Math.max(0,Math.floor((Date.now()-new Date(date).getTime())/60000));return mins<1?"Just now":mins<60?`${mins}m ago`:mins<1440?`${Math.floor(mins/60)}h ago`:`${Math.floor(mins/1440)}d ago`}

feed.addEventListener("click",async(e)=>{
  const btn=e.target.closest("button[data-action]");if(!btn)return;
  const {action,id}=btn.dataset;
  if(action==="share"){if(navigator.share){try{await navigator.share({title:"CreateWorld AI",text:"Check out this creator post on CreateWorld AI",url:location.href})}catch{}}else{await navigator.clipboard?.writeText(location.href);toast("Link copied.");}return}
  if(!supabase){showNotice("Connect Supabase","Likes and comments become shared community features after you connect Supabase and run the database setup.");return}
  if(!currentUser){openAuth();return}
  if(action==="like"){
    const {data:existing}=await supabase.from("likes").select("id").eq("post_id",id).eq("user_id",currentUser.id).maybeSingle();
    const result=existing?await supabase.from("likes").delete().eq("id",existing.id):await supabase.from("likes").insert({post_id:id,user_id:currentUser.id});
    if(result.error)toast(result.error.message);else loadFeed();
  }else if(action==="comment"){
    const comment=prompt("Write a comment:");if(!comment?.trim())return;
    const {error}=await supabase.from("comments").insert({post_id:id,user_id:currentUser.id,body:comment.trim().slice(0,1000)});
    if(error)toast(error.message);else{toast("Comment posted.");loadFeed()}
  }
});

$("#openUpload").addEventListener("click",()=>openUpload());
function openUpload(){if(!supabase){showNotice("Connect Supabase first","To publish real posts, configure Supabase and create a public Storage bucket named videos using the SQL/setup guide.");return}if(!currentUser){openAuth();return}uploadDialog.showModal()}
$("#uploadForm").addEventListener("submit",async(e)=>{
  e.preventDefault();if(!supabase||!currentUser)return;
  const file=$("#postFile").files[0],caption=$("#postCaption").value.trim();
  if(!file)return;if(file.size>100*1024*1024){toast("Please choose a video smaller than 100 MB.");return}
  if(!file.type.startsWith("video/")){toast("Please select a video file.");return}
  const ext=file.name.split(".").pop().toLowerCase(),path=`${currentUser.id}/${crypto.randomUUID()}.${ext}`;
  toast("Uploading video…");
  const up=await supabase.storage.from("videos").upload(path,file,{contentType:file.type,upsert:false});
  if(up.error){toast(up.error.message);return}
  const {data:{publicUrl}}=supabase.storage.from("videos").getPublicUrl(path);
  const {error}=await supabase.from("posts").insert({user_id:currentUser.id,caption,video_url:publicUrl});
  if(error){toast(error.message);return}
  uploadDialog.close();$("#uploadForm").reset();toast("Your post is live!");loadFeed();
});

async function loadSpotlight(){
  if(!supabase)return;
  const {data}=await supabase.from("profiles").select("id,username,avatar_url").limit(5);
  if(!data?.length)return;
  $("#spotlight").innerHTML=data.map(p=>`<div class="spot-person"><span class="user-dot">${escapeHtml((p.username||"C")[0].toUpperCase())}</span><div><strong>${escapeHtml(p.username||"Creator")}</strong><small>Community creator</small></div></div>`).join("");
}

function switchView(view){
  document.querySelectorAll("[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  if(view==="home"){location.hash="";loadFeed();return}
  if(view==="explore"){location.hash="explore";showNotice("Explore creators","Trending videos, creator discovery and personalized recommendations are part of the next development milestone.");return}
  if(view==="studio"){location.hash="studio";showNotice("AI Creator Studio","This section is ready for AI API integration: video generation, image generation, voice, scripts and prompts. Add provider API keys on the secure backend, never in browser JavaScript.");return}
  if(view==="profile"){if(!currentUser){openAuth();return}showNotice("Your profile",`Signed in as ${currentUser.user_metadata?.username||currentUser.email}. Profile editing, followers and creator analytics are next modules.`);return}
  if(view==="messages"){showNotice("Messages","Private messaging needs its own database tables, realtime subscriptions and abuse controls. It will be added as a separate secure module.");return}
  if(view==="settings"){showNotice("Settings","Account preferences, privacy, blocking and notification settings will be added here.");return}
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-view]");if(b){e.preventDefault();switchView(b.dataset.view)}});
document.querySelectorAll("[data-feed]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll("[data-feed]").forEach(x=>x.classList.toggle("active",x===b));feedMode=b.dataset.feed;loadFeed()}));
$("#searchInput").addEventListener("keydown",e=>{if(e.key==="Enter"){const q=e.target.value.trim();if(q)showNotice("Search",`Search for “${q}” will be connected to creator and video discovery in the next module.`)}});
$("#notificationBtn").addEventListener("click",()=>showNotice("Notifications","Likes, comments, follows and system notifications will appear here once the notification module is connected."));
init();
